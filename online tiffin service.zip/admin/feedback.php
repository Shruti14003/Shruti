<?php require_once("config.php")?> 
    <?php

if(isset($_POST["submit"])) {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $phone= $_POST["phone"];
  $message= $_POST["message"];
  

  $sql= "INSERT INTO `feedback`(`id`, `name`, `email`, `phone`, `message`) VALUES (NULL,'$name','$email','$phone','$message')"; 
  if($conn->query($sql)==TRUE)
                {
                    echo'<script>alert("Successfully")</script>';
                    echo '<script>window.location.href = "index.php";</script>';

                }
                else
                {
                    echo"Error"  . $sql . "<br>" . $conn->error;
                }
}
?>
<!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title>Online Dabba Services</title>
  <style>
    *{
  margin: 0;
  padding: 0;
  outline: none;
  border: none;
  text-decoration: none;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body{
  background: rgb(226, 226, 226);
}
nav{
  position: sticky;
  top: 0;
  bottom: 0;
  height: 100vh;
  left: 0;
  width: 90px;
  background: #fff;
  overflow: hidden;
  transition: 1s;
}
nav:hover{
  width: 280px;
  transition: 1s;
}
.logo{
  text-align: center;
  display: flex;
  margin: 10px 0 0 10px;
  padding-bottom: 3rem;
}
.logo span{
  font-weight: bold;
  padding-left: 15px;
  font-size: 18px;
  text-transform: uppercase;
}
a{
  position: relative;
  width: 300px;
  font-size: 14px;
  color: rgb(85, 83, 83);
  display: table;
  padding: 15px;
}
.nav-item{
  position: relative;
  top: 12px;
  margin-left: 10px;
}
a:hover{
  background: #eee;
}
a:hover i{
  color: #34AF6D;
  transition: 0.5s;
}
.logout{
  position: absolute;
  bottom: 0;
}

.container{
  display: flex;
}

/* MAin Section */
.main h1{
  position: relative;
  padding: 0;
  width: 100%;
  color: orange;
  align-items: center;
 
 
}
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  
}
body{
  
  background-color: #f5f5f5;
  font-family: Arial, Helvetica, sans-serif;
}
.wrapper{
  background-color: #fff;
  width: 700px;
  padding: 25px;
  margin: 25px auto 0;
  margin-left: 400px;
}
.wrapper h2{
  background-color: #fcfcfc;
  color:#ffc727;
  font-size: 24px;
  padding: 10px;
  margin-bottom: 20px;
  text-align: center;
  border: 1px;
}
h4{
  padding-bottom: 5px;
  color:#ffc727;
}
.input-group{
  margin-bottom: 8px;
  width: 100%;
  display: flex;
  padding: 5px 0;
}
.input-box{
  width: 100%;
  margin-right: 12px;
  float: left;
}
.input-box:last-child{
  margin-right: 0;
}
.name{
  padding: 14px 10px 14px 50px;
  width: 100%;
  background-color: #fcfcfc;
  border: 1px solid #00000033;
  outline: none;
  letter-spacing: 1px;
  border-radius: 3px;
  color: #333;
}

.input-box .icon{
  width: 48px;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  color: #333;
  background-color: #f1f1f1;
  border-radius: 2px 0 0 2px;
  transition: 0.3s;
  font-size: 20px;
  pointer-events: none;
  border: 1px solid #00000033;
  border-right: none;
}
.input-box select{
  display: inline-block;
  width: 100%;
  padding: 12px;
  background-color: #fcfcfc;
  text-align: center;
  font-size: 16px;
  outline: none;
  border: 1px solid #c0bfbf;
  cursor: pointer;
  transition: all 0.2s ease;
}
.input-box select:focus{
  background-color: #ffc727;
  color: #fff;
  text-align: center;
}
button{
  width:100px;
  background: transparent;
  border: none;
  background: #ffc727;
  color: black;
  padding: 15px;
  border-radius: 4px;
  font-size: 16px;
  transition: all 0.35s ease;
}
button:hover{
  cursor: pointer;
  background: #fcf;
}
  

  </style> 
 </head>
<body>

    <section class="main">
      <div class="main-top">
        <ceneter>
           
      <div class="wrapper">
        <h2>Feedback</h2>
        <form method="POST">
           
           <div class="input-group">
                <div class="input-box">
                  
                    <input type="text" name="name" placeholder=" Enter Your Name" required class="name">
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                  
                    <input type="text" name="email" placeholder=" Enter Your Email" required class="name">
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                  
                    <input type="text" name="phone" placeholder=" Enter Your Phone No" required class="name">
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    
                    <input type="text" name="message" placeholder=" Enter Your Suggestions.." required class="name">
                </div>
            </div>
    
    <button type="submit" name="submit">submit</button>
    <a href="index.php">Go To Home Page</a> 
      </section>

  </div>

</body>
</html>
