<?php

include "config.php";

if(isset($_POST["sign-up"])) {
  $username = $_POST["username"];
  $email = $_POST["email"];
  $password = $_POST["password"];
  $confirmPassword = $_POST["confirm-password"];

  if(empty($username) OR empty($password) OR empty($confirmPassword)) {
    echo "<script> alert('All fields are required') </script>";
  }
  elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<script> alert('Invalid Email Format'); </script>";
  }
  elseif($password != $confirmPassword) {
    echo "<script> alert('Password does not match'); </script>";
  }
  else {
    $insertQuery = "INSERT INTO `signup`(`ID`,`Username`, `Email`, `Password`, `Confirm_password`) VALUES (NULL,'$username', '$email', '$password', '$confirmPassword');";

    $result = mysqli_query($conn, $insertQuery);

    if($result) {
      echo "<script> alert('Registered Successfully'); </script>";
    }
  }

  mysqli_close($conn);
}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign Up</title>
    <style>
      h1 {
        color: orange;
      }
      body {
        justify-content: center;
        display: flex;
      }
      input {
        display: block;
        width: 360px;
        height: 40px;
        margin: 20px;
        border: none;
        outline: none;
        font-size: 20px;
        border-bottom: 1px solid orange;
        border-radius: 10px;
      }
      p {
        font-size: 20px;
      }
      div {
        background-color: rgba(116, 123, 117, 0.4);
        text-align: center;
        height: 500px;
        padding: 5px;
        margin: 100px;
      }
      .btnone {
        display: block;
        width: 125px;
        padding: 0.2rem;
        color: white;
        font-size: 1.4rem;
        text-decoration: none;
        text-align: center;
        border: 1 px solid rgb(17, 11, 11);
        border-radius: 10px;
        background-color: orange;
      }
    </style>
  </head>
  <body>
    <div>
      <form action="" method="post" class="form-container">
        <h1>Sign Up</h1>
        <input
          type="text"
          name="username"
          placeholder="Enter Username"
        />
        <input type="email" name="email" placeholder="Enter email" />
        <input
          type="password"
          name="password"
          placeholder="Enter password "
        />
        <input
          type="password"
          name="confirm-password"
          placeholder="Enter confirm  password "
        />
        <table align="center">
          <tr>
            <td><input type="submit" class="btnone" name="sign-up" value="Sign Up"></td>
          </tr>
        </table>
        <p>Do you have an account <a href="login1.php">Login Now</a></p>
      </form>
    </div>
  </body>
</html>
