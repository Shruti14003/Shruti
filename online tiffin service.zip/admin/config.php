<?php

$conn = mysqli_connect('localhost','root','','db') or die('connection failed');


?>