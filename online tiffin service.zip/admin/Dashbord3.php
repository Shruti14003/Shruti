<?php require_once("config.php")?> 
    <?php

if(isset($_POST["submit"])) {
  $name = $_POST["name"];
  $address = $_POST["address"];
  $mobileno= $_POST["mobileno"];
  $gender = $_POST["gender"];
  $work= $_POST["work"];
  $salary= $_POST["salary"];

  $sql= "INSERT INTO `managestaff`(`ID`, `name`, `address`, `mobileno`, `gender`, `work`, `salary`) VALUES (NULL,'$name','$address','$mobileno','$gender','$work','$salary')";
            if($conn->query($sql)==TRUE)
                {
                    echo'<script>alert("Successfully")</script>';
                }
                else
                {
                    echo"Error"  . $sql . "<br>" . $conn->error;
                }
}



if(isset($_GET['delete'])){
  $delete_id = $_GET['delete'];
  $delete_query = mysqli_query($conn, "DELETE FROM `managestaff` WHERE id = $delete_id ") or die('query failed');
  if($delete_query){
     header('location:dashbord3.php');
     $message[] = 'product has been deleted';
  }else{
     header('location:dashbord3.php');
     $message[] = 'product could not be deleted';
  };
};

?>

<!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title>Online Dabba Services</title>
  <style>
    *{
  margin: 0;
  padding: 0;
  outline: none;
  border: none;
  text-decoration: none;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body{
  background: rgb(226, 226, 226);
}
nav{
  position: sticky;
  top: 0;
  bottom: 0;
  height: 100vh;
  left: 0;
  width: 90px;
  background: #fff;
  overflow: hidden;
  transition: 1s;
}
nav:hover{
  width: 280px;
  transition: 1s;
}
.logo{
  text-align: center;
  display: flex;
  margin: 10px 0 0 10px;
  padding-bottom: 3rem;
}
.logo span{
  font-weight: bold;
  padding-left: 15px;
  font-size: 18px;
  text-transform: uppercase;
}
a{
  position: relative;
  width: 300px;
  font-size: 14px;
  color: rgb(85, 83, 83);
  display: table;
  padding: 15px;
}
.nav-item{
  position: relative;
  top: 12px;
  margin-left: 10px;
}
a:hover{
  background: #eee;
}
a:hover i{
  color: #34AF6D;
  transition: 0.5s;
}
.logout{
  position: absolute;
  bottom: 0;
}

.container{
  display: flex;
}

/* MAin Section */
.main h1{
  position: relative;
  padding: 20px;
  width: 100%;
  color: orange;
 
}
P{
  font-size : 50px;
  color: white;
  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
  text-align:center;
  font-weight: bold;
  margin-top:25px;
  margin-bottom: 10px;
  width: 700px;
  padding: 25px;
  margin: 25px auto 0;
  margin-left: 400px;
}
.center {
  display: block;
  margin-left: 350px;
  margin-right: auto;
  width: 60%;
}
h3{
  font-family:times new roman;
   margin-left: 280px;
}


.btn{
     
     width:200px;
     padding:0.2rem;
     color:black;
     font-size:19px;
     text-decoration:none;
     margin-left:300px;
     text-align:center;
     border:1 px solid rgb(17,11,11);
     border-radius:20px;
     background-color:orange;

 } 
btn:hover{
  cursor: pointer;
  background:blue;
}


  

  </style> 
 </head>
<body>
  <div class="container">
    <nav>
      <ul>
        <li>
          <span class="nav-item">Admin</span>
        </a></li><br>
        <li><a href="Dashbord1.php">
          <span class="nav-item">Home</span>
        </a></li><br>

        
        <li><a href="Dashbord2.php">
          <span class="nav-item">Manage Meal</span>
        </a></li><br>
        
        <li><a href="Dashbord3.php">
          <span class="nav-item"> View Simple Reports</span>
        </a></li><br>
      
       
        
        <li><a href="index.php" class="logout">
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>


    <section class="main">
      <div class="main-top">
        <ceneter>
        <h1>View Simple Report..</h1>  
     
      <div class="wrapper">

<a href="login_s.php" class="btn">Login </a><br><br>

<a href="signup_s.php" class="btn">Sign Up </a><br><br>

<a href="meal_S.php" class="btn">Meal  </a><br><br>

<a href="feedback_s.php" class="btn">Feedback </a><br><br>

<a href="staff_s.php" class="btn">Staff </a><br><br>

<a href="deliveryboy_s.php" class="btn">Delivery Boy </a><br><br>

<a href="payment_s.php" class="btn">Payment</a><br><br>

<a href="payment_report.php" class="btn">Payment Report</a><br><br>
      </section>
  </div>
 
</body>
</html>
