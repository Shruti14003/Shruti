 <html>
  <head><title>Login</title>
  <?php require_once("Config.php")?> 
  
    <style>
  
    h1{
     color:orange;
    }
    body{
        justify-content:center;
        display:flex;	
    }
    input{
        display:block;
        width:360px;
        height:40px;
        margin:20px;
        border:none;
        outline:none;
        font-size:20px;
        border-bottom:1px solid orange;
        border-radius:10px;
    }
   
    p{
      font-size:20px;
        
    }
    div{
        background-color:rgba(116, 123, 117, 0.4);
        text-align :center;
        height:350px;
        width: 400px;
        padding: 20px;
        margin: 150px;
    }
    .btnone {
     
        width: 125px;
        padding: 0.2rem;
        color: white;
        font-size: 1.4rem;
        text-decoration: none;
        text-align: center;
        border-radius: 10px;
        background-color: orange;
      }


    </style>
</head>
  <body>
  
        <div>
        <?php
session_start();
if(isset($_POST['Login']))
{
    $login=$_POST['login_var'];
    $Password=$_POST['password'];
    $query="SELECT * FROM `signup` WHERE Username='$login' ";
    $res=mysqli_query($conn,$query);
    $numrows=mysqli_num_rows($res);
    if($numrows == 1)
    {
        $row=mysqli_fetch_assoc($res);
        $hashedPasswordFromDatabase = $row['Password'];
        $userSubmittedPassword = $_POST['password'];
        if ($userSubmittedPassword === $hashedPasswordFromDatabase) 
        {
            $_SESSION["login_sess"]="1";
            $_SESSION["login_Username"]=$row['Username'];
            header("location:index.php");
        }
        else
        {
            header("location:login1.php?Loginerror=@".$login);
        }
    }   
    else
    {
            header("location:login1.php?Loginerror=$".$login);
    }
    
}
?>
            <form class="form-container" action="" method="POST">
                <h1>Login </h1>
                <?php
                    if(isset($_GET['Loginerror'])){
                        $Loginerror=$_GET['Loginerror'];
                    }
                    if(!empty($Loginerror)){
                        echo '<script>alert("Invaild Login credentials...please Try Again")</script>';
                    }
                    ?>
                <input type="text"  name="login_var" values="<?php if(!empty($Loginerror)){echo $Loginerror;}?>" id="username" placeholder="Enter Username" required>
                <input type="password" name="password"  id="password" placeholder="Enter password " required>
                <button class=btnone name="Login">Login</button>
              
                  <p>Don't have an account <a href="Sign Up.php">Sign Up Now</a></p>
                 
            </form>
          </div>
        </div>
       
  </body>
  </html>
