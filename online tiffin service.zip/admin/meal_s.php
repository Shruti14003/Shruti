<!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title>Online Dabba Services</title>
  <style>

/* MAin Section */
.main h1{
  position: relative;
  padding: 20px;
  width: 100%;
  color: orange;
 
}
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  
}
body{
  
  background-color: #f5f5f5;
  font-family: Arial, Helvetica, sans-serif;
}
.wrapper{
  background-color: #fff;
  width: 700px;
  padding: 25px;
  margin: 25px auto 0;
  margin-left: 400px;
}
.wrapper h2{
  background-color: #fcfcfc;
  color:#ffc727;
  font-size: 24px;
  padding: 10px;
  margin-bottom: 20px;
  text-align: center;
  border: 1px;
}
table,td,th{
  border: 1px solid black;
  padding: 10px;
}


.btn{
     width:125px;
     padding:0.2rem;
     color:black;
     font-size:0.5 rem;
     text-decoration:none;   
     border-radius:10px;
     background-color:orange;
     text-align:center;   
}
.btn:hover{
  cursor: pointer;
  background: pink;
}
    
  </style> 
 </head>
<body>


    <section class="main">
    <div class="main-top">
      <h1>View Meals..</h1>
      <center>
        <div class="wrapper">
        <h2>Meal Form</h2>
        <form method="POST">

                 
                <?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "","db");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Print host information
//echo "Connect Successfully. Host info: " . mysqli_get_host_info($link);
$sql = "SELECT * FROM `products`";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table border='1' align='ceneter' cellpadding='3' cellspacing='3'>";
echo"<caption><h1>Report</h1></caption>";
echo "<tr>";
echo "<th>ID</th>";
 echo "<th>Name</th>";
 echo "<th>Price</th>";
 echo "<th>Image</th>";
 echo "<th>Quantity</th>";

echo "</tr>";
while($row = mysqli_fetch_array($result)){
echo "<tr>";
echo "<td>" . $row['id'] . "</td>";
 echo "<td>" . $row['name'] . "</td>";
 echo "<td>" . $row['price'] . "</td>";
 echo "<td>" . $row['image'] . "</td>";
 echo "<td>" . $row['quantity'] . "</td>";
echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>      
 

    </div>
    </center>
  </section>
</div>
<a href="dashbord3.php" class="btn">Back </a><br><br>  
</body>
</html>
