<!DOCTYPE html>
<html>
<head>
    <title>Online Dabba Services</title>
    <style>
        h1,h2,h3{
            color:orange;
            padding: 1px;
            margin:1px;
            text-align:center;
        }
        .receipt{
           
            font-size:20px;
            color:black;
            width: 1000px;
        }
        label{
            font-size:20px;
        }
        select,input{
            font-size:15px;
        }
     
        .btn
        {
         
            display: inline-block;
            padding: 10px 20px;
             background-color: orange;
            color: black;
            text-align: center;
             text-decoration: none;
             border: 1px solid #3498db;
             border-radius: 5px;
            cursor: pointer;
             transition: background-color 0.3s;
        }   
         .btn:hover
         {
            cursor: pointer;
            background: #fcf;
        }
        p{
        font-weight: bold;
        margin-top: 10px;
        justify-content:center;
        }
    </style>
</head>
<body>
<div class="receipt" style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ccc;">

<h1>Receipt</h1>
        <h2>..Online Dabba Services..</h2>
        <h3>Phone:9699011327</h3>
        <hr>
        <h5>Date And Time</h5>
         <p id="datetime"></p>
         <hr>
        <form method="post">
       
        <label>Select Your Meal:</label>
        <select id="item1" name="item1" > 

            <option value="HalkaMeal" name="meal">Halka Meal(2200)</option> 
            <option value="RegularMeal" name="meal">Regular Meal(2800)</option> 
            <option value="MiniMeal" name="meal">Mini Meal(2600)</option> 
            <option value="PremiumMeal" name="meal">Premium Meal(3400)</option> 
            <option value="SimpleDesiMeal" name="meal">Simple Desi Meal(2200)</option> 
            <option value="FullMeal" name="meal">FullMeal(2200)</option>   
        </select> <br>
            <br>
            
            <label for="price1">Enter Your Price :</label>
            <input type="text" name="price1" id="price1"><br>
            
           <br>
           <hr>
           <?php
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $items = array($_POST["item1"]);
        $prices = array($_POST["price1"]);
        $subTotal = array_sum($prices);
        $gst = $subTotal * 0.05;
        $tax = $subTotal * 0.10;
        $total = $subTotal + $gst + $tax;
    ?>
    
<p>Subtotal: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $subTotal; ?>&nbsp;&nbsp;rs</p>

<p>GST (5%):&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $gst; ?>&nbsp;&nbsp;rs</p>
<p>Tax (10%):&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $tax; ?>&nbsp;&nbsp;rs</p>
<hr>
<p>Total: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $total; ?>&nbsp;&nbsp;rs</p>

   

    <?php } ?>
            
            <input type="submit" value="Generate Receipt"  class="btn">
            <button onclick="window.print()" class="btn">Print Receipt</button>
            <a href="index.php" class="btn">go back !</a>
        </form>
        <br>
       
        <h3>❤️Thank you for your purchase!</h3>
        <h3>(. ❛ ᴗ ❛.)</h3> 

    <script>
    function updateTime() {
      var now = new Date();
      var datetimeElement = document.getElementById('datetime');
      datetimeElement.innerHTML = now.toLocaleString();
    }

    updateTime();
    setInterval(updateTime, 1000); // Update every second
  </script>
</body>
</html>
