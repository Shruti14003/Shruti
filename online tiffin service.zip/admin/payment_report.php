<!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title>Online Dabba Services</title>
  <style>
  table,td,th
{
border: 1px solid black;
padding: 10px;
margin-left:190px;
margin-top:60px;
width:80%;
text-align:center;
font-size:20px;
}
.btn{
     width:125px;
     padding:0.2rem;
     color:black;
     font-size:0.5 rem;
     text-decoration:none;   
     border-radius:10px;
     background-color:orange;
     text-align:center;   
}
.btn:hover{
  cursor: pointer;
  background: pink;
}
label{
     font-size: 20px;
     padding:0.2rem;
     color:black;
     font-size:0.5 rem;     
     font-family:times new roman;
     text-align:center; 
}
form{
  
 text-align:center;
}
h1{
    font-size:50px;  
    color:orange;
    text-align:center;
}  
  </style> 
 </head>

 <h1>View Payment Report..</h1>
  <form action="" method="GET">
<label>From Date:</label>
<input type="date" class="date" name="from_date" value="<?php if(isset($_GET['from_date'])){ echo $_GET['from_date']; } ?>"><br><br>
<label>To Date:</label>
<input type="date" class="date" name="to_date" value="<?php if(isset($_GET['to_date'])){ echo $_GET['to_date']; } ?>">   
<br><br>
<button type="submit">Filter</button>
</form>
<table class="table table-borderd">
<thead>
<tr>
<th>ID</th>
<th>Full Name</th>
<th>E-mail</th>
<th>Place</th>
<th>Gender</th>
<th>Card_Number</th>
<th>Card_Cvc</th>
<th>Date</th>
<th>Meal</th>
<th>Quantity</th>
<th>Price</th>                                    
</tr></thead><tbody>                
                        
                            
<?php 
$conn = mysqli_connect('localhost','root','','db');
if(isset($_GET['from_date']) && isset($_GET['to_date']))
{
               $from_date = $_GET['from_date'];
	       $to_date = $_GET['to_date'];

               $query = "SELECT * FROM payment WHERE Date BETWEEN '$from_date' AND '$to_date' ";
               $query_run = mysqli_query($conn, $query);

                if(mysqli_num_rows($query_run) > 0)
                {
                     foreach($query_run as $row)
                     {
                     ?>
                      <tr>                       
              <td><?= $row['ID']; ?></td>		
			 <td><?= $row['full_name']; ?></td>
   			 <td><?= $row['email_address']; ?></td>
			<td><?= $row['place']; ?></td>
			<td><?= $row['gender']; ?></td>
			<td><?= $row['card_number']; ?></td>
			<td><?= $row['card_cvc']; ?></td>
			<td><?= $row['Date']; ?></td>
			<td><?= $row['meal']; ?></td>
			<td><?= $row['quantity']; ?></td>
			<td><?= $row['price']; ?></td>
                         </tr>
                        <?php
                      }
              }
              else
              {
                       echo "No Record Found";
              }
	   }
?>
</tbody>
</table>

<a href="dashbord3.php" class="btn">Back </a><br><br>     
        
</div>
</section>
</body>
</html>
