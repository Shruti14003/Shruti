
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <link rel="stylesheet" href="payment.css">
    <?php require_once("config.php")?> 
    <?php
error_reporting(0);
if(isset($_POST["submit"])) {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $place = $_POST["place"];
  $select= $_POST["select"]; 
  $card_number = $_POST["card_number"];
  $card_cvc = $_POST["card_cvc"];
  $Date = $_POST["Date"];
  $meal = $_POST['meal']; 
  $quantity = $_POST['quantity']; 
  $price = $_POST['price']; 

            
            // Calculate the price based on meal type and quantity (replace with your logic) 
            $mealPrices = [ 
                'HalkaMeal' => 2200, 
                'RegularMeal' => 2800, 
                'MiniMeal' => 2600, 
                'PremiumMeal' => 3400, 
                'SimpleDesiMeal' => 2200, 
                'FullMeal' => 2200,   
            ]; 
            $price = $mealPrices[$meal] * $quantity; 

 $sql="INSERT INTO `payment`(`ID`, `full_name`, `email_address`, `place`, `gender`, `card_number`, `card_cvc`, `Date`, `meal`, `quantity`, `price`) VALUES (NULL,'$name','$email','$place','$select','$card_number','$card_cvc','$Date','$meal','$quantity','$price')";

  if ($conn->query($sql) === TRUE) { 
   
    echo '<script>alert("payment Successfully😊"); window.location.href = "receipt.php";</script>';
   
    
		
                 

            } else { 
                echo "Error: " . $sql . "<br>" . $conn->error; 
            }  
            $conn->close(); 


      
}
?>
</head>
<body>
    <div class="wrapper">
        <h2>Payment Form</h2>
        <form  action="" method="POST">
            <h4> User Account Information</h4>
            <div class="input-group">
                <div class="input-box">
                    <input type="text" name="name" placeholder="Enter Your Full Name" required class="name">
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <input type="text" name="email" placeholder="Enter Your Adress" required class="name">
                </div>
            </div>
	<div class="input-group">
                <div class="input-box">
                    <input type="text" name="place" placeholder="Nearby-Place" required class="name">
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                   
                    <select name="select">
                        <option>Gender</option>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                    </select>
                    
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                   
                    <div class = "payment">
                          Payment Details :&nbsp;&nbsp;&nbsp; 
                         <input type="radio" name="payment"  id="cash" value="cash" onclick="EnableDisable();">&nbsp;Cash On Delivery &nbsp;&nbsp;&nbsp; 
   
						 <input type="radio" name="payment"  id="credit" value="credit" onclick="EnableDisable();">&nbsp;Credit Card  
                   </div>
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <input type="tel"  name="card_number" id="CreditNum" placeholder="Card Number" maxlength=12 required class="name" disabled="disabled">
                </div>
            </div>
            <div class="input-group">
                <div class="input-box">
                    <input type="tel" name="card_cvc" id="CreditNumber" placeholder="Card CVC" maxlength=4 required class="name" disabled="disabled">
                </div>
                <div class="input-box">
                   <input type="date" name="Date">
       			
                </div>
            </div>

	<select id="FoodType" name="meal"> 
		<option  name="meal">Select Your Meal</option> 
            <option value="HalkaMeal" name="meal">Halka Meal</option> 
            <option value="RegularMeal" name="meal">Regular Meal</option> 
            <option value="MiniMeal" name="meal">Mini Meal</option> 
            <option value="PremiumMeal" name="meal">Premium Meal</option> 
            <option value="SimpleDesiMeal" name="meal">Simple Desi Meal</option> 
            <option value="FullMeal" name="meal">FullMeal</option>   
        </select> 
       
      
      
      
        <input type="number" id="quantity" placeholder="Enter Month of meals" 
name="quantity">

      <br><br>
 
        <label style="color:black;"for="total">Total Amount:</label> 
        <span  style="color:black;"id="total" name="price">0.0</span> 
        <br><br> 
 
    




            <div class="input-group">
                <div class="input-box">
                    <button type="submit" name="submit">PAY NOW</button>
            </div>
	
        </form>
        <a href="index.php" class="btn">go back!</a>
    </div>
	<script>
	 const mealPrices = { 
                HalkaMeal: 2200, 
               RegularMeal : 2800, 
                MiniMeal : 2600, 
                PremiumMeal : 3400, 
                SimpleDesiMeal: 2200, 
                FullMeal : 2200, 
 
               
        }; 
        // JavaScript to handle meal order and total calculation 
        const mealTypeSelect = document.getElementById('FoodType'); 
        const quantityInput = document.getElementById('quantity'); 
        const totalSpan = document.getElementById('total'); 
        const orderBtn = document.getElementById('orderBtn'); 
        // const mealprice = 80; 
 
        mealTypeSelect.addEventListener('change', updateTotal); 
        quantityInput.addEventListener('input', updateTotal); 
 
        function updateTotal() { 
            const mealType = mealTypeSelect.value; 
            const quantity = parseInt(quantityInput.value); 
 
            if (mealPrices[mealType] && !isNaN(quantity)) { 
                const total = mealPrices[mealType] * quantity; 
                totalSpan.textContent = `${total.toFixed(2)}`; 
            } 
        }
	 orderBtn.addEventListener('click', () => { 
           const mealType = mealTypeSelect.value; 
            const quantity = parseInt(quantityInput.value); 
            if (mealPrices[mealType] && !isNaN(quantity)) { 
                const total = mealPrices[mealType] * quantity; 
                confirm(`Order Placed:\n\nHalka Meal : 80\nQuantity: 
${quantity}\nFood Type: ${ mealType}\n\nTotal Price: ${total.toFixed(2)}`); 
                window.location.href = "pay.html"; 
            } else { 
                confirm('Please select a valid meal type and quantity.'); 
            } 
        }); 
	       function EnableDisable()
		   {
		       var credit = document.getElementById("credit");
			   var creditnum= document.getElementById("CreditNum");
			   var creditno = document.getElementById("CreditNumber");
			   creditnum.disabled=credit.checked? false:true;
			   creditno.disabled=credit.checked? false:true;
			   creditnum.value="";
			   if(!creditnum.disabled)
			   {
			     creditnum.focus();
			   }
		   }
	</script>
</body>

</html>