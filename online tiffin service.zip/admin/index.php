<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Online Dabba Services</title>
    <!-- StyleSheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <header class="header">
      <a href="Login.php" class="logo">The Food Your Door<span class="yellow">step</span></a>

      <nav class="navbar">
        <a href="#home">Home</a>
        <a href="products.php">Meals</a>
        <a href="#whyus">Why Us</a>
        <a href="#about">About Us</a>
	 <a href="#review">Review</a>
        <a href="#contact">Contact Us</a>
        <a href="feedback.php">Feedback</a>
	<a href="receipt.php">Receipt</a>
        <a href="payment.php" class="btn">Order Meal</a> 
      </nav>
    </header>

    <!-- Home -->
    <section class="home" id="home">
      <div class="content">
        <h2> Welcome To Online Dabba services</h2>
        <h1>DO COME & VISIT <span class="yellow">OUR MEAL.</span></h1>
        <p>
          "Ghar Ka Khana Just The Way You Want"
        </p>
        <a href="login1.php" class="btn">Login Now</a>
      </div>
      <div class="image">
        <img src="img/img1.png" alt="" />
      </div>
    </section>

    
  

    <!--  Why us -->
    <section class="whyus" id="whyus">
      <div class="whyus">
        <table>
        <center>
          <h1><span class="yellow">Why</span> We are the Best</h1>
          <h2>Learn more about our meal options</h2>
          <tr>
                 <td><img src="img/whyus1.png" alt="whyus1"/><br><h2>Ghar ka khana</h2><p>Delicious Home Style food with minimal oil/masales</p></td>
               <td><img src="img/whyus2.png" alt="whyus2"/><br><h2>Short Trial</h2>
             <p>You can try the delicious Dabba! meals for 1 week to know what every one is raving about!</p></td>	
          </tr><br> 
          <tr>
               <td><img src="img/whyus3.png" alt="whyus3"/><br><h2>Amazing variety</h2><p>You will love the variety coz at Online Dabba-No dish is repeated All Month!!</p></td>
             <td><img src="img/whyus4.png" alt="whyus4"/><br><h2>Simple Cancellation System</h2>
             <p>Cancelling your meal will take seconds & a credit for cancelled meal will be provided to your wallet</p></td>
          </tr><br> 	 
               <td><img src="img/whyus5.png" alt="whyus5"><br><h2>Easy Ordering</h2><p>Ordering your meal on the Online Dabba services! Website will take less than 2 mins!!</p></td>
               <td><img src="img/whyus6.png" alt="whyus6"><h2>My Account</h2><p>Manage your orders - Cancellations, Order Renewals, Shares etc within seconds</p></td>
            </tr><br>
        </table>
        </center>
      </div>	
      </section>

      
    <!-- About 1 -->
    <section class="about" id="about">
      <div class="image">
        <img src="img/indian-plate.png" alt="" />
      </div>
      <div class="content">
        <h3><span class="yellow">About </span> Online Dabba Services</h3>
        <p>
          Mumbai first food-commerce Tiffn service which allows you to order delicious Home style
          food in convenient packaging-ALL ONLINE.
        </p>
        <P>
          Our Customers loves Mumbai Tiffn service for it's authentic Indian food and customer eservices.  
        </P>
      </div>
    </section>



	<section class="review" id="review">
      <div class="content">
              
	<h1><span class="yellow">Re</span>view</h1>		
      			
			
<table cellspacing=20>
 <tr>
 <td>
<h1>"Anindita"</h1>
<span style="color:orange" class="fa fa-star"></span>
<span style="color:orange"  class="fa fa-star"></span>
<span style="color:orange"  class="fa fa-star"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
<h2>Food quality and quantity was very good .
 they devliver the food on<br> time very nice service :)</h2>
</a></td>


	    <td>
<h1>"Mayank Varshney"</h1>
<span style="color:orange" class="fa fa-star"></span>
<span style="color:orange"  class="fa fa-star"></span>
<span style="color:orange"  class="fa fa-star"></span>
<span style="color:orange" class="fa fa-star"></span>
<span class="fa fa-star"></span>
<h2>Good food quality....and quite <br>satisfactory food quantity,
it was really a good experience<br>,the service was quite good and i was really 
happy to hire them,my <br>college also took services from them and he was also satisfied.</h2>
</a></td>


<td>
<h1>"Krushal Lalvani"</h1>
<span style="color:orange" class="fa fa-star"></span>
<span style="color:orange"  class="fa fa-star"></span>
<span style="color:orange"  class="fa fa-star"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
<h2>Mr.varma is a fantastic manager,extremely versatile and <br>acccommodating.hard to find such brilliant people anymore.</h2>
</a></td>


</table>	


      </div>
    </section>
   
   
    <!-- contact -->
    <section class="contact" id="contact">
      <div class="content">
        <center>
        <table>
        <h1><span class="yellow">CONTACT US</span>GET IN TOUCH </h1><br>
        <br><h2>Order a healthy and well-balanced meal designed by our expert dieticion in any part of MUMBAI.</h2>
        <br><h2>It's all homemade ..... "Ghar ka khana just the way you want"</h2><br>
	<h3>Lunch cancellation time – 11pm Night before.</h3>
	<h3>Dinner cancellation time – 2pm Same Day.</h3>
      <br><br><tr>
          <td><h3>Mobile Number</h3></td><td>(+91)9699011327</td></tr>
        <tr>
          <td><h3>E-mail</h3></td> <td>info@mumbaitiffins.com</td></tr>

      
        </div>
    </center>
  </table>
    </section>
   
  
   <!-- Footer -->
    <footer class="footer">
      <div class="top">
        <div class="content">
          <a href="" class="logo">The Food Your Door<span class="yellow">step</span></a>
        </div>

        <div class="links">
          <div class="link">
            <h4>Contact Information</h4>
            <div>

              <span>Mumbai,Maharastra</span>
            </div>
            <div>
           
              <span>Onlinedabbaservices@gmail.com</span>
            </div>
          </div>

          <div class="link">
            <h4>Quick Links</h4>
            <a href="#">meal plans</a>
            <a href="#">About Us</a>
            <a href="#">Contact Us</a>
            <a href="#">Order Now</a>
          </div>

          <div class="link">
            <h4>Legal</h4>
            <a href="#">Privacy Policy</a>
            <a href="#">Term of Use</a>
            <a href="#">Conditions</a>
            <a href="#">Location</a>
          </div>

          <div class="link">
            <h4>Connect with Us</h4>
            <div>
             
              <span>Instagram</span>
            </div>
            <div>
             
              <span>Twitter</span>
            </div>
            <div>
            
              <span>Facebook</span>
            </div>
          </div>
        </div>
      </div>
      <div class="bottom">
        <p>Online Dabba Services..</p>
      </div>
    </footer>
    <!-- Scripts -->
    <script src="main.js"></script>
    
  </body>
</html>
